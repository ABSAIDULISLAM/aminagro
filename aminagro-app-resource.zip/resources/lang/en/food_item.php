<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Food Item Page Language Files
    |--------------------------------------------------------------------------
    */

    'title' 			=> 'Food Item List',
	'name' 				=> 'Item Name',
	'add_new_unit' 		=> 'Add New Food Item',
	'update_food_unit' 	=> 'Update Food Item'
	
];
