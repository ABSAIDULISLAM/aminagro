<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Branch List Page Language Files
    |--------------------------------------------------------------------------
    */

    'title' 			=> 'Branch List',
	'sl' 				=> 'S/L',
	'branch_name' 		=> 'Branch Name',
	'builder_name' 		=> 'Builder Name',
	'phone_no' 			=> 'Phone Number',
	'email' 			=> 'Email',
	'setup_date'		=> 'Setup Date',
	'address'			=> 'Address',
	'add_new_branch'	=> 'Add New Branch',
	'edit_branch'		=> 'Edit Branch Information'
];
