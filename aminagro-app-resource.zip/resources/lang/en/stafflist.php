<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Staff list Language Files
    |--------------------------------------------------------------------------
    */

    'title' 			=> 'Staff List',
	'add_staff' 		=> 'Add Staff',
	'image' 			=> 'Image',
	'staff_name' 		=> 'Staff Name',
	'email' 			=> 'Email',
	'mobile_no' 		=> 'Mobile No',
	'designation' 		=> 'Designation',
	'joining_date' 		=> 'Joining Date',
	'salary' 			=> 'Salary',
	'status' 			=> 'Status',
];
