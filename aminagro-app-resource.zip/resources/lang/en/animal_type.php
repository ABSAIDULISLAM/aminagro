<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Animal Type Page Language Files
    |--------------------------------------------------------------------------
    */

    'title' 				=> 'Animal Type List',
	'name' 					=> 'Type Name',
	'add_new_type' 			=> 'Add New Type',
	'update_type' 			=> 'Update Type'
];
