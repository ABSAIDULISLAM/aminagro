<?php

return [

    /*
    |--------------------------------------------------------------------------
    | User list Language Files
    |--------------------------------------------------------------------------
    */

    'title' 			=> 'User List',
	'add_user' 			=> 'Add User',
	'image' 			=> 'Image',
	'id' 				=> 'ID',
	'user_name' 		=> 'User Name',
	'email' 			=> 'Email',
	'mobile_no' 		=> 'Mobile No',
	'designation' 		=> 'Designation',
	'user_type' 		=> 'User Type',
	'joining_date' 		=> 'Joining Date',
	'salary' 			=> 'Salary',
	'status' 			=> 'Status',
];
