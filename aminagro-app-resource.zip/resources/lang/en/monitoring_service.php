<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Monitoring service Page Language Files
    |--------------------------------------------------------------------------
    */

    'title' 				=> 'Monitoring Services List',
	'name' 					=> 'Service Name',
	'new_service' 			=> 'Add New Service',
	'update_service' 		=> 'Update Service'
	
];
