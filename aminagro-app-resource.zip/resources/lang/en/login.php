<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Login Page Language Files
    |--------------------------------------------------------------------------
    */

    'title' 			=> 'Dairy Firm Management System',
	'email' 			=> 'Email',
    'password' 			=> 'Password',
	'login' 			=> 'Log in',
	'select-branch'		=> 'CHOOSE A BRANCH',
	'signout'			=> 'Sign out'
];
