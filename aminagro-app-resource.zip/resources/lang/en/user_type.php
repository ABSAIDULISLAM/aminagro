<?php

return [

    /*
    |--------------------------------------------------------------------------
    | User Type Page Language Files
    |--------------------------------------------------------------------------
    */

    'title' 					=> 'User Type List',
	'user_type' 				=> 'User Type',
	'add_user_type_access'		=> 'Add User Type Access',
	'update_user_type_access'	=> 'Update User Type Access',
	'give_all_access'			=> 'Give All Access'
	
];
