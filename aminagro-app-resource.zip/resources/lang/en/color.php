<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Color Page Language Files
    |--------------------------------------------------------------------------
    */

    'title' 			=> 'Color List',
	'name'				=> 'Color Name',
	'update_color'		=> 'Update Color',
	'add_new_color'		=> 'Add New Color'
];
