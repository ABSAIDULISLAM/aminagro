<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Human Resource Form Entry Page Language Files
    |--------------------------------------------------------------------------
    */

    'title' 							=> 'Profile Information',
	'full_name' 						=> 'Full Name',
	'email_address' 					=> 'Email Address',
	'phone_number' 						=> 'Phone Number',
	'nid' 								=> 'NID',
	'enter_national_ID_number'			=> 'Enter National ID Number',
	'designation'						=> 'Designation',
	'user_type'							=> 'User Type',
	'present_address'					=> 'Present Address',
	'permanent_address'					=> 'Parmanent Address',
	'basic_salary'						=> 'Basic Salary',
	'gross_salary'						=> 'Gross Salary',
	'joining_date'						=> 'Joining Date',
	'resign_date'						=> 'Resign Date',
	'profile_image'						=> 'Profile Image',
	'password'							=> 'Password',
	'confirm_password'					=> 'Confirm Password',
	'resign_description'				=> 'Resign Description'
	
];
