<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Food Unit Page Language Files
    |--------------------------------------------------------------------------
    */

    'title' 			=> 'Food Unit List',
	'name' 				=> 'Unit Name',
	'add_new_unit' 		=> 'Add New Food Unit',
	'update_food_unit' 	=> 'Update Food Unit'
	
];
