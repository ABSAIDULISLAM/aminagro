<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Vaccine List Page Language Files
    |--------------------------------------------------------------------------
    */

    'title' 			=> 'Vaccine List',
	'name' 				=> 'Vaccine Name',
	'period' 			=> 'Period (Days)',
	'repeat' 			=> 'Repeat Vaccine',
	'dose' 				=> 'Dose',
	'note' 				=> 'Note',
	'title' 			=> 'Vaccine List',
	'add_new_vaccine'	=> 'Add New Vaccine',
	'update_vaccine'	=> 'Update Vaccine Information',
	'days'				=> 'Days',
	'dose_ex'			=> 'Table or 5.0 ml etc',
	'repeat_note'		=> 'If repeat you will get warning for same cow when time.'
];
