<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Login Page Language Files
    |--------------------------------------------------------------------------
    */

    'title' 			=> 'Stall List',
	'all_stall_list'	=> 'All Stall List',
	'details'			=> 'Details',
	'status'			=> 'Status',
	'stall_no'			=> 'Stall Number',
	'booked'			=> 'Booked',
	'available'			=> 'Available',
	'edit_stall'		=> 'Edit Stall Information',
	'add_stall'			=> 'Add New Stall'
];
