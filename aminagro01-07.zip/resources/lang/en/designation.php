<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Designation Page Language Files
    |--------------------------------------------------------------------------
    */

    'title' 					=> 'Designation List',
	'designation'				=> 'Designation Name',
	'add_new_designation'		=> 'Add New Designation',
	'update_designation'		=> 'Update Designation'
];
