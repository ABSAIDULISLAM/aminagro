@extends('layouts.layout')
@section('title', __('manage_cow.calf_list_title'))
@section('content')
<section class="content-header">
  <h1><i class="icon-list"></i> {{__('manage_cow.calf_list_title') }}</h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> {{__('same.home') }}</a></li>
    <li class="active">{{__('manage_cow.calf_list_title') }}</li>
  </ol>
</section>
<section class="content"> @include('common.message')
  <div class="box box-success">
    <div class="box-header with-border" align="right"> <a href="{{  url('calf/create')  }}" class="btn btn-success btn-sm" data-toggle="modal"> <i class="fa fa-plus-square"></i> <b>{{__('same.add_new') }}</b> </a> <a href="{{URL::to('calf')}}" class="btn btn-warning btn-sm"> <i class="fa fa-refresh"></i> <b>{{__('same.refresh') }}</b> </a> </div>
    <div class="box-body">
      <div class="row">
        <div class="col-sm-12">
          <div class="form-group">
            <div class="table-responsive">
              <table class="table table-bordered table-striped table-responsive">
                <thead>
                  <tr>
                    <th>{{__('manage_cow.id') }}</th>
                    <th>{{__('manage_cow.image') }}</th>
                    <th>{{__('manage_cow.mother_id') }}</th>
                    <th>{{__('manage_cow.gender') }}</th>
                    <th>{{__('manage_cow.animal_type') }}</th>
                    <th>{{__('manage_cow.buy_date') }}</th>
                    <th>{{__('manage_cow.buying_price') }}</th>
                    <th>{{__('manage_cow.calf_status') }}</th>
                    <th>{{__('same.action') }}</th>
                  </tr>
                </thead>
                <tbody>
                
                @foreach($all_animals as $animals)
                <tr>
                  <td><label class="label label-default lblfarm">{{$animals->id}}</label></td>
                  <td> @if($animals->pictures !='')
                    @if(file_exists('storage/app/public/uploads/animal/'.explode('_', $animals->pictures)[0])) <img src='{{asset("storage/app/public/uploads/animal")}}/{{explode("_", $animals->pictures)[0]}}' class="img-thumbnail" width="50px"> @else <img src='{{asset("public/custom/img/noImage.jpg")}}' class="img-circle" width="60px"> @endif
                    @else <img src='{{asset("public/custom/img/noImage.jpg")}}' class="img-circle" width="60px"> @endif </td>
                  <td>000{{$animals->animal_id}}
                    <!-- Modal Start -->
                    <div class="modal fade" id="view{{$animals->id}}" tabindex="-1" role="dialog">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title"><i class="fa fa-info-circle edit-color"></i> {{__('manage_cow.calf_details') }}</h4>
                          </div>
                          <div class="modal-body">
                            <table class="table table-bordered table-striped table-responsive">
                              <tbody>
                                <tr>
                                  <td>{{__('manage_cow.stall_no') }}</td>
                                  <td> @if(isset($animals->animal_shed_object->shed_number))
                                    {{$animals->animal_shed_object->shed_number}}
                                    @endif </td>
                                </tr>
                                <tr>
                                  <td>{{__('manage_cow.dob') }}</td>
                                  <td>{{ Carbon\Carbon::parse($animals->DOB)->format('m/d/Y') }}</td>
                                </tr>
                                <tr>
                                  <td>{{__('manage_cow.age') }}</td>
                                  <td>{{$animals->age}} {{__('manage_cow.days_or') }} <?php echo number_format((float)$animals->age / 30,2,".","."); ?> {{__('manage_cow.month') }}</td>
                                </tr>
                                <tr>
                                  <td>{{__('manage_cow.weight') }}</td>
                                  <td>{{$animals->weight}}</td>
                                </tr>
                                <tr>
                                  <td>{{__('manage_cow.height') }}</td>
                                  <td>{{$animals->height}}</td>
                                </tr>
                                <tr>
                                  <td>{{__('manage_cow.color') }}</td>
                                  <td> @if(isset($animals->animal_color_object->color_name))
                                    {{$animals->animal_color_object->color_name}}
                                    @endif </td>
                                </tr>
                                <tr>
                                  <td>{{__('manage_cow.buy_form') }}</td>
                                  <td>{{$animals->buy_from}}</td>
                                </tr>
                                <tr>
                                  <td>{{__('manage_cow.previous_vaccine_done') }}</td>
                                  <td>{{$animals->previous_vaccine_done}}</td>
                                </tr>
                                <tr>
                                  <td>{{__('manage_cow.created_by') }}</td>
                                  <td>{{  $animals->name  }} <b>({{  $animals->user_type  }})</b></td>
                                </tr>
                                <tr>
                                  <td>{{__('Father ID') }}</td>
                                  <td>
                                    {{$animals->father_id}}
                                    </td>
                                </tr>
                                                                <tr>
                                  <td>{{__('Father Name') }}</td>
                                  <td>
                                    {{$animals->father_name}}
                                    </td>
                                </tr>
                                                                <tr>
                                  <td>{{__('Company Name') }}</td>
                                  <td>
                                    {{$animals->company_name}}
                                    </td>
                                </tr>
                                                                <tr>
                                  <td>{{__('Claf Blood') }}</td>
                                  <td>
                                    {{$animals->claf_blood}}
                                    </td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                          <div class="modal-footer"></div>
                        </div>
                        <!-- /.modal-content -->
                      </div>
                      <!-- /.modal-dialog -->
                    </div>
                    <!-- /.modal -->
                  </td>
                  <td>{{$animals->gender}}</td>
                  <td> @if(isset($animals->animal_animalType_object->type_name))
                    {{$animals->animal_animalType_object->type_name}}
                    @endif </td>
                  <td> @if(!empty($animals->buy_date))
                    {{date('M d, Y', strtotime($animals->buy_date))}}
                    @endif </td>
                  <td>{{App\Library\farm::currency($animals->buying_price)}}</td>
                  <td> @if($animals->sale_status==1)
                    <label class="label label-warning lblfarm">{{__('manage_cow.sold') }}</label>
                    @elseif($animals->sale_status==2)
                    <label class="label label-danger lblfarm">{{__('Dead') }}</label>
                    @else
                    <label class="label label-success lblfarm">{{__('manage_cow.available') }}</label>
                    @endif </td>
                  <td><div class="form-inline">
                      <div class = "input-group"> <a href="#view{{$animals->id}}" class="btn btn-primary btn-xs" data-toggle="modal" title="{{__('same.view') }}"><i class="icon-eye"></i></a> </div>
                      <div class = "input-group"> <a href="{{ route('calf.edit', $animals->id) }}" class="btn btn-success btn-xs" title="{{__('same.edit') }}"><i class="icon-pencil"></i></a> </div>
                      <div class = "input-group"> {{Form::open(array('route'=>['calf.destroy',$animals->id],'method'=>'DELETE'))}}
                        <button type="submit" confirm="{{__('same.delete_confirm') }}" class="btn btn-danger btn-xs confirm" title="{{__('same.delete') }}"><i class="icon-trash"></i></button>
                        {!! Form::close() !!} </div>
                    </div></td>
                </tr>
                @endforeach
                </tbody>
                
              </table>
              <div class="col-md-12" align="center"> {{$all_animals->render()}} </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="box-footer"> </div>
  </div>
</section>
@endsection 