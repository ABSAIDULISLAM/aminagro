<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BuyMedicine extends Model
{
    protected $table = "buy_medicine";
    protected $fillable = [
        'branch', 
        'suppliers', 
        'medicine', 
        'quantity',
        'unit',
        'price',
        'description',
        'date',
    ];

}
