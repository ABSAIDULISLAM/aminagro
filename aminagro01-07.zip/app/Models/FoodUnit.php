<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FoodUnit extends Model
{
    protected $table = 'food_units';
    protected $fillable = ['name'];
}
