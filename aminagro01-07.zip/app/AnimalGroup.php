<?php

namespace App;

use App\Models\Group;
use Illuminate\Database\Eloquent\Model;

class AnimalGroup extends Model
{
    protected $guarded = [];

    
}
